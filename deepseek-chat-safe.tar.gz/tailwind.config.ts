import type { Config } from "tailwindcss";

export default {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
      },
      spacing: {
        '8': '8px',
        '12': '12px',
        '16': '16px',
        '20': '20px',
        '24': '24px',
        '32': '32px',
        '40': '40px',
        '48': '48px',
        '80': '80px',
      },
      fontSize: {
        '13': '13px',
        '14': '14px',
        '15': '15px',
        '18': '18px',
        '20': '20px',
      },
      borderRadius: {
        '8': '8px',
        '12': '12px',
      },
    },
  },
  plugins: [],
} satisfies Config;
